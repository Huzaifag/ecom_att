<x-website.product-grid 
    :title="$title" 
    :products="$products" 
    :showViewAllButton="true"
    viewAllText="View All Top Rated"
    viewAllLink="/top-rated"
/>