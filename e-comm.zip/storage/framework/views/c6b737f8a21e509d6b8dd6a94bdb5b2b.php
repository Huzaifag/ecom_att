<?php if (isset($component)) { $__componentOriginaled42cf205faea5ffc4276df15810560b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled42cf205faea5ffc4276df15810560b = $attributes; } ?>
<?php $component = App\View\Components\Website\ProductGrid::resolve(['title' => $title,'products' => $products,'showViewAllButton' => true,'viewAllText' => 'View All Top Rated','viewAllLink' => '/top-rated'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.product-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\ProductGrid::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled42cf205faea5ffc4276df15810560b)): ?>
<?php $attributes = $__attributesOriginaled42cf205faea5ffc4276df15810560b; ?>
<?php unset($__attributesOriginaled42cf205faea5ffc4276df15810560b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled42cf205faea5ffc4276df15810560b)): ?>
<?php $component = $__componentOriginaled42cf205faea5ffc4276df15810560b; ?>
<?php unset($__componentOriginaled42cf205faea5ffc4276df15810560b); ?>
<?php endif; ?><?php /**PATH E:\laravel\Freelance\e-comm\resources\views/components/website/top-rated-products.blade.php ENDPATH**/ ?>