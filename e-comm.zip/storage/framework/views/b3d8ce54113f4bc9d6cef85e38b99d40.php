<div class="container my-5">
    <h2 class="mb-4 fw-bold text-dark"><?php echo e($title); ?></h2>

    <?php if(count($products) > 0): ?>
        <!-- Static Grid Layout -->
        <div class="row g-4 mb-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal4318359f4406510a51d06640665b5280 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4318359f4406510a51d06640665b5280 = $attributes; } ?>
<?php $component = App\View\Components\Website\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4318359f4406510a51d06640665b5280)): ?>
<?php $attributes = $__attributesOriginal4318359f4406510a51d06640665b5280; ?>
<?php unset($__attributesOriginal4318359f4406510a51d06640665b5280); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4318359f4406510a51d06640665b5280)): ?>
<?php $component = $__componentOriginal4318359f4406510a51d06640665b5280; ?>
<?php unset($__componentOriginal4318359f4406510a51d06640665b5280); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- View All Products Button -->
        <?php if($showViewAllButton): ?>
            <div class="text-center mt-4">
                <?php if($viewAllLink): ?>
                    <a href="<?php echo e($viewAllLink); ?>" class="btn-view-all">
                        <?php echo e($viewAllText); ?>

                    </a>
                <?php else: ?>
                    <button class="btn-view-all">
                        <?php echo e($viewAllText); ?>

                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="text-center py-5">
            <p class="text-muted">No products available at the moment.</p>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn-view-all {
            background: #008B8B;
            color: white;
            border: none;
            padding: 16px 30px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            text-decoration: none;
            display: inline-block;
        }

        .btn-view-all:hover {
            background: #006666;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 139, 139, 0.3);
            color: white;
            text-decoration: none;
        }
    </style>
<?php $__env->stopPush(); ?><?php /**PATH E:\laravel\Freelance\e-comm\resources\views/components/website/product-grid.blade.php ENDPATH**/ ?>