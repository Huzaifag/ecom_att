
<?php $__env->startSection('content'); ?>
    <section class="hero-section container-fluid my-4">
        <div class="row justify-content-between align-items-center">
            <div class="col-md-3 categories" id="category-dropdown-content">
                <?php echo $__env->make('website.component.categories-list', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="col-md-12 hero-image" id="hero-image">
                <img src="<?php echo e(asset('/images/website/hero.png')); ?>" alt="Hero Image" >
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal553fb257b96cf8a70bc0f8699e4f0098 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal553fb257b96cf8a70bc0f8699e4f0098 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.website.service-cards','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.service-cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal553fb257b96cf8a70bc0f8699e4f0098)): ?>
<?php $attributes = $__attributesOriginal553fb257b96cf8a70bc0f8699e4f0098; ?>
<?php unset($__attributesOriginal553fb257b96cf8a70bc0f8699e4f0098); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal553fb257b96cf8a70bc0f8699e4f0098)): ?>
<?php $component = $__componentOriginal553fb257b96cf8a70bc0f8699e4f0098; ?>
<?php unset($__componentOriginal553fb257b96cf8a70bc0f8699e4f0098); ?>
<?php endif; ?>
    </section>
    <section class="category-items container-fluid mb-4">
        <?php if (isset($component)) { $__componentOriginaled051692e6d133c8f96eebb7f76255e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled051692e6d133c8f96eebb7f76255e7 = $attributes; } ?>
<?php $component = App\View\Components\Website\CategoryItems::resolve(['title' => 'Shop By Category'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.category-items'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\CategoryItems::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled051692e6d133c8f96eebb7f76255e7)): ?>
<?php $attributes = $__attributesOriginaled051692e6d133c8f96eebb7f76255e7; ?>
<?php unset($__attributesOriginaled051692e6d133c8f96eebb7f76255e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled051692e6d133c8f96eebb7f76255e7)): ?>
<?php $component = $__componentOriginaled051692e6d133c8f96eebb7f76255e7; ?>
<?php unset($__componentOriginaled051692e6d133c8f96eebb7f76255e7); ?>
<?php endif; ?>
    </section>
    <section class="new-arrivals container-fluid mb-4">
        <?php if (isset($component)) { $__componentOriginalf4794e113c62f2fba8002445d2bde47e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf4794e113c62f2fba8002445d2bde47e = $attributes; } ?>
<?php $component = App\View\Components\Website\NewArrivals::resolve(['title' => 'New Arrival'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.new-arrivals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\NewArrivals::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf4794e113c62f2fba8002445d2bde47e)): ?>
<?php $attributes = $__attributesOriginalf4794e113c62f2fba8002445d2bde47e; ?>
<?php unset($__attributesOriginalf4794e113c62f2fba8002445d2bde47e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4794e113c62f2fba8002445d2bde47e)): ?>
<?php $component = $__componentOriginalf4794e113c62f2fba8002445d2bde47e; ?>
<?php unset($__componentOriginalf4794e113c62f2fba8002445d2bde47e); ?>
<?php endif; ?>
    </section>
    <section class="featured-products container-fluid mb-4"
        style="background-image: url('<?php echo e(asset('images/website/vector12.png')); ?>'); background-size: cover; background-position: center;">
        <?php if (isset($component)) { $__componentOriginal80bfa67384456195eeeb4ab5f3ec9573 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80bfa67384456195eeeb4ab5f3ec9573 = $attributes; } ?>
<?php $component = App\View\Components\Website\FeaturedProducts::resolve(['title' => 'Promo Product'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.featured-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\FeaturedProducts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80bfa67384456195eeeb4ab5f3ec9573)): ?>
<?php $attributes = $__attributesOriginal80bfa67384456195eeeb4ab5f3ec9573; ?>
<?php unset($__attributesOriginal80bfa67384456195eeeb4ab5f3ec9573); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80bfa67384456195eeeb4ab5f3ec9573)): ?>
<?php $component = $__componentOriginal80bfa67384456195eeeb4ab5f3ec9573; ?>
<?php unset($__componentOriginal80bfa67384456195eeeb4ab5f3ec9573); ?>
<?php endif; ?>
    </section>
    <section class="best-seller-products container-fluid mb-4">
        <?php if (isset($component)) { $__componentOriginalcbe8a79a7c2b39fb13cf71778922d6ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcbe8a79a7c2b39fb13cf71778922d6ae = $attributes; } ?>
<?php $component = App\View\Components\Website\BestSellerProducts::resolve(['title' => 'Best Sellers'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.best-seller-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\BestSellerProducts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcbe8a79a7c2b39fb13cf71778922d6ae)): ?>
<?php $attributes = $__attributesOriginalcbe8a79a7c2b39fb13cf71778922d6ae; ?>
<?php unset($__attributesOriginalcbe8a79a7c2b39fb13cf71778922d6ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcbe8a79a7c2b39fb13cf71778922d6ae)): ?>
<?php $component = $__componentOriginalcbe8a79a7c2b39fb13cf71778922d6ae; ?>
<?php unset($__componentOriginalcbe8a79a7c2b39fb13cf71778922d6ae); ?>
<?php endif; ?>
    </section>
    <section class="top-rated-products container-fluid mb-4">
        <?php if (isset($component)) { $__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3 = $attributes; } ?>
<?php $component = App\View\Components\Website\TopRatedProducts::resolve(['title' => 'Top Rated'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.top-rated-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\TopRatedProducts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3)): ?>
<?php $attributes = $__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3; ?>
<?php unset($__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3)): ?>
<?php $component = $__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3; ?>
<?php unset($__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3); ?>
<?php endif; ?>
    </section>
    <section class="hero-section container-fluid my-4">
        <div class="row justify-content-between align-items-center">
            <div class="col-md-12 hero-image"
                style="background-image: url(<?php echo e(asset('/images/website/offer-banner.png')); ?>); background-size: cover; background-position: center; min-height: 470px; border-radius: 15px;">
                <div class="decription-section">
                    <h3>GET 30% OFF YOUR ORDER OF $100</h3>
                    <h2>BEST MEN’S COLLECTION</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                        et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                    <button>Buy Now</button>
                </div>
            </div>
        </div>
    </section>

    <section class="top-rated-products container-fluid mb-4">
        <?php if (isset($component)) { $__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3 = $attributes; } ?>
<?php $component = App\View\Components\Website\TopRatedProducts::resolve(['title' => 'Special Offer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('website.top-rated-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Website\TopRatedProducts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3)): ?>
<?php $attributes = $__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3; ?>
<?php unset($__attributesOriginalb089fdbab3bd71c00c3190a4fcf350e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3)): ?>
<?php $component = $__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3; ?>
<?php unset($__componentOriginalb089fdbab3bd71c00c3190a4fcf350e3); ?>
<?php endif; ?>
    </section>
    <section class="newsletter">
        <?php echo $__env->make('website.component.newsletter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laravel\Freelance\e-comm\resources\views/website/pages/index.blade.php ENDPATH**/ ?>